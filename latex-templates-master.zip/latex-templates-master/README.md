latex-templates
===============

Useful LaTeX templates for frequently used document types.

Templates that are prefixed with `usb` were specifically made for courses at
Universidad Simón Bolívar.
