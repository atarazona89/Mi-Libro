# Formato de Proyecto de Grado de la Universidad Simón Bolívar

Esta plantilla de LaTeX tiene todo lo que necesitas para empezar a
escribir *el libro de la tesis*.

Utiliza `make` para una compilación completa de las referencias.
Puedes usar solo `pdflatex` sobre el documento principal, `tesis.tex`, cuando
quieras realizar cambios sencillos sobre el documento y verlos reflejados
rápidamente.
