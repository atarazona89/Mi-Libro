# Formato de informe para Gráficas 2

Éste es un formato de informe proveído el profesor Víctor Theoktisto para
utilizar en Computación Gráfica II.

Utiliza `make` para una compilación completa del documento, incluídas las
referencias. Es posible que necesites instalar algunos paquetes de LaTeX antes
de  poder compilar el documento; consulta con tu manejador de paquetes (en el
caso de MacTeX, puedes instalar la herramienta gráfica *TeX Live Utility*).
